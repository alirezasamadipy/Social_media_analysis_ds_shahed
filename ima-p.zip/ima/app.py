"""
سرور وب تحلیل شبکه اجتماعی
درس ساختمان داده — دکتر زهرا پوربهمن
"""

from flask import Flask, jsonify, render_template, request
from storage import load_network, save_network

app = Flask(__name__)
network = load_network()


def persist():
    save_network(network)


@app.route("/")
def index():
    return render_template("index.html")


# ─── مدیریت کاربران و روابط ───────────────────────────────────────────────────

@app.route("/api/users", methods=["GET"])
def get_users():
    users = [
        {"id": uid, "name": name, "friend_count": len(network.adj[uid])}
        for uid, name in network.users.items()
    ]
    users.sort(key=lambda x: x["name"])
    return jsonify(users)


@app.route("/api/users", methods=["POST"])
def add_user():
    data = request.get_json(force=True)
    user_id = (data.get("id") or "").strip()
    name = (data.get("name") or "").strip()
    if not user_id or not name:
        return jsonify({"ok": False, "error": "شناسه و نام الزامی است"}), 400
    if not network.add_user(user_id, name):
        return jsonify({"ok": False, "error": "این شناسه قبلاً وجود دارد"}), 400
    persist()
    return jsonify({"ok": True})


@app.route("/api/users/<user_id>", methods=["PUT"])
def update_user(user_id):
    data = request.get_json(force=True)
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"ok": False, "error": "نام الزامی است"}), 400
    if not network.update_user(user_id, name):
        return jsonify({"ok": False, "error": "کاربر پیدا نشد"}), 404
    persist()
    return jsonify({"ok": True})


@app.route("/api/users/<user_id>", methods=["DELETE"])
def delete_user(user_id):
    if not network.remove_user(user_id):
        return jsonify({"ok": False, "error": "کاربر پیدا نشد"}), 404
    persist()
    return jsonify({"ok": True})


@app.route("/api/friendships", methods=["GET"])
def get_friendships():
    data = network.to_dict()
    edges = []
    for e in data["friendships"]:
        edges.append({
            "user1": e["user1"],
            "user1_name": network.users[e["user1"]],
            "user2": e["user2"],
            "user2_name": network.users[e["user2"]],
        })
    return jsonify(edges)


@app.route("/api/friendships", methods=["POST"])
def add_friendship():
    data = request.get_json(force=True)
    u, v = data.get("user1"), data.get("user2")
    if not network.add_friendship(u, v):
        return jsonify({"ok": False, "error": "افزودن دوستی ممکن نیست"}), 400
    persist()
    return jsonify({"ok": True})


@app.route("/api/friendships", methods=["DELETE"])
def delete_friendship():
    data = request.get_json(force=True)
    u, v = data.get("user1"), data.get("user2")
    if not network.remove_friendship(u, v):
        return jsonify({"ok": False, "error": "این دوستی وجود ندارد"}), 404
    persist()
    return jsonify({"ok": True})


# ─── پردازش‌های اجباری ────────────────────────────────────────────────────────

@app.route("/api/friends/<user_id>")
def api_friends(user_id):
    result = network.list_friends(user_id)
    if result is None:
        return jsonify({"ok": False, "error": "کاربر پیدا نشد"}), 404
    return jsonify({"ok": True, "friends": result})


@app.route("/api/connected")
def api_connected():
    u, v = request.args.get("u"), request.args.get("v")
    result = network.are_connected(u, v)
    if result is None:
        return jsonify({"ok": False, "error": "کاربر پیدا نشد"}), 404
    return jsonify({"ok": True, "connected": result})


@app.route("/api/shortest-path")
def api_shortest_path():
    u, v = request.args.get("u"), request.args.get("v")
    result = network.shortest_path(u, v)
    if result is None:
        return jsonify({"ok": False, "error": "کاربر پیدا نشد"}), 404
    return jsonify({"ok": True, "path": result, "length": max(0, len(result) - 1)})


@app.route("/api/suggest/<user_id>")
def api_suggest(user_id):
    result = network.suggest_friends(user_id)
    if result is None:
        return jsonify({"ok": False, "error": "کاربر پیدا نشد"}), 404
    return jsonify({"ok": True, "suggestions": result})


@app.route("/api/groups")
def api_groups():
    return jsonify({"ok": True, "groups": network.find_groups()})


@app.route("/api/most-friends")
def api_most_friends():
    return jsonify({"ok": True, "users": network.most_friends()})


@app.route("/api/common-friends")
def api_common_friends():
    u, v = request.args.get("u"), request.args.get("v")
    result = network.common_friends(u, v)
    if result is None:
        return jsonify({"ok": False, "error": "کاربر پیدا نشد"}), 404
    return jsonify({"ok": True, "common": result})


@app.route("/api/network-info")
def api_network_info():
    return jsonify({"ok": True, "info": network.network_info()})


@app.route("/api/distances/<user_id>")
def api_distances(user_id):
    result = network.distances_from(user_id)
    if result is None:
        return jsonify({"ok": False, "error": "کاربر پیدا نشد"}), 404
    return jsonify({"ok": True, "distances": result})


# ─── پردازش‌های اختیاری ───────────────────────────────────────────────────────

@app.route("/api/betweenness")
def api_betweenness():
    return jsonify({"ok": True, "users": network.betweenness_centrality()})


@app.route("/api/communities")
def api_communities():
    return jsonify({"ok": True, "communities": network.detect_communities()})


@app.route("/api/spread")
def api_spread():
    try:
        k = int(request.args.get("k", 2))
    except ValueError:
        k = 2
    return jsonify({"ok": True, "result": network.optimize_spread(k)})


if __name__ == "__main__":
    app.run(debug=True, port=8080)
