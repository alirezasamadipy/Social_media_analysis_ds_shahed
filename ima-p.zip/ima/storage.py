"""ذخیره و بازیابی شبکه اجتماعی در فایل JSON."""

import json
import os
from graph import SocialNetwork

DEFAULT_PATH = os.path.join(os.path.dirname(__file__), "data", "network.json")


def load_network(path: str = DEFAULT_PATH) -> SocialNetwork:
    if not os.path.exists(path):
        return SocialNetwork()
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return SocialNetwork.from_dict(data)


def save_network(network: SocialNetwork, path: str = DEFAULT_PATH) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(network.to_dict(), f, ensure_ascii=False, indent=2)


def create_sample_network() -> SocialNetwork:
    """شبکه نمونه مطابق مثال پروژه."""
    net = SocialNetwork()
    users = [
        ("ali", "علی"),
        ("amir", "امیر"),
        ("hassan", "حسن"),
        ("sara", "سارا"),
        ("nika", "نیکا"),
        ("laleh", "لاله"),
        ("mehdi", "مهدی"),
        ("saeed", "سعید"),
        ("omid", "امید"),
    ]
    for uid, name in users:
        net.add_user(uid, name)

    friendships = [
        ("ali", "amir"),
        ("amir", "hassan"),
        ("hassan", "sara"),
        ("sara", "nika"),
        ("sara", "laleh"),
        ("omid", "saeed"),
        ("omid", "mehdi"),
        ("saeed", "mehdi"),
    ]
    for u, v in friendships:
        net.add_friendship(u, v)

    return net
