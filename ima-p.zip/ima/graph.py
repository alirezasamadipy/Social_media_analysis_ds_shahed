"""
ماژول گراف شبکه اجتماعی
ساختمان داده: لیست مجاورت (Adjacency List) با set برای جستجوی O(1)
"""

from collections import deque, defaultdict
from typing import Dict, List, Optional, Set, Tuple


class SocialNetwork:
    """گراف بدون‌جهت شبکه اجتماعی با لیست مجاورت."""

    def __init__(self):
        # id -> name
        self.users: Dict[str, str] = {}
        # id -> set of friend ids
        self.adj: Dict[str, Set[str]] = {}

    # ─── مدیریت کاربران و روابط ───────────────────────────────────────────────

    def add_user(self, user_id: str, name: str) -> bool:
        """افزودن کاربر جدید. اگر شناسه تکراری باشد False برمی‌گرداند."""
        if user_id in self.users:
            return False
        self.users[user_id] = name
        self.adj[user_id] = set()
        return True

    def remove_user(self, user_id: str) -> bool:
        """حذف کاربر و تمام روابط او. O(درجه)."""
        if user_id not in self.users:
            return False
        for friend in list(self.adj[user_id]):
            self.adj[friend].discard(user_id)
        del self.adj[user_id]
        del self.users[user_id]
        return True

    def update_user(self, user_id: str, name: str) -> bool:
        """ویرایش نام کاربر."""
        if user_id not in self.users:
            return False
        self.users[user_id] = name
        return True

    def add_friendship(self, u: str, v: str) -> bool:
        """افزودن دوستی دوطرفه. O(1)."""
        if u not in self.users or v not in self.users or u == v:
            return False
        if v in self.adj[u]:
            return False
        self.adj[u].add(v)
        self.adj[v].add(u)
        return True

    def remove_friendship(self, u: str, v: str) -> bool:
        """حذف دوستی دوطرفه. O(1)."""
        if u not in self.users or v not in self.users:
            return False
        if v not in self.adj[u]:
            return False
        self.adj[u].discard(v)
        self.adj[v].discard(u)
        return True

    def get_user_name(self, user_id: str) -> Optional[str]:
        return self.users.get(user_id)

    def _display(self, user_id: str) -> str:
        return self.users.get(user_id, user_id)

    # ─── ۱. لیست دوستان ───────────────────────────────────────────────────────

    def list_friends(self, user_id: str) -> Optional[List[dict]]:
        """لیست دوستان یک کاربر. O(درجه)."""
        if user_id not in self.users:
            return None
        return [
            {"id": f, "name": self.users[f]}
            for f in sorted(self.adj[user_id], key=lambda x: self.users[x])
        ]

    # ─── ۲. آیا دو کاربر مرتبط‌اند؟ ───────────────────────────────────────────

    def are_connected(self, u: str, v: str) -> Optional[bool]:
        """بررسی اتصال با BFS. O(V + E)."""
        if u not in self.users or v not in self.users:
            return None
        if u == v:
            return True
        return self._bfs_reachable(u, v)

    def _bfs_reachable(self, start: str, target: str) -> bool:
        visited = {start}
        queue = deque([start])
        while queue:
            node = queue.popleft()
            for neighbor in self.adj[node]:
                if neighbor == target:
                    return True
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)
        return False

    # ─── ۳. کوتاه‌ترین مسیر ───────────────────────────────────────────────────

    def shortest_path(self, u: str, v: str) -> Optional[List[dict]]:
        """کوتاه‌ترین مسیر با BFS. O(V + E). None اگر مسیر نباشد."""
        if u not in self.users or v not in self.users:
            return None
        if u == v:
            return [{"id": u, "name": self.users[u]}]

        parent: Dict[str, Optional[str]] = {u: None}
        queue = deque([u])
        found = False

        while queue:
            node = queue.popleft()
            for neighbor in self.adj[node]:
                if neighbor not in parent:
                    parent[neighbor] = node
                    if neighbor == v:
                        found = True
                        break
                    queue.append(neighbor)
            if found:
                break

        if not found:
            return []

        path_ids = []
        cur = v
        while cur is not None:
            path_ids.append(cur)
            cur = parent[cur]
        path_ids.reverse()
        return [{"id": i, "name": self.users[i]} for i in path_ids]

    # ─── ۴. پیشنهاد دوست ─────────────────────────────────────────────────────

    def suggest_friends(self, user_id: str) -> Optional[List[dict]]:
        """پیشنهاد دوست: دوستانِ دوستان که هنوز دوست نیستند. O(مجموع درجات همسایه‌ها)."""
        if user_id not in self.users:
            return None
        friends = self.adj[user_id]
        candidates: Set[str] = set()
        for friend in friends:
            for fof in self.adj[friend]:
                if fof != user_id and fof not in friends:
                    candidates.add(fof)
        return [
            {"id": c, "name": self.users[c]}
            for c in sorted(candidates, key=lambda x: self.users[x])
        ]

    # ─── ۵. گروه‌های شبکه (مؤلفه‌های هم‌بند) ───────────────────────────────────

    def find_groups(self) -> List[List[dict]]:
        """پیدا کردن مؤلفه‌های هم‌بند با DFS. O(V + E)."""
        visited: Set[str] = set()
        groups = []

        for user_id in self.users:
            if user_id not in visited:
                component = []
                stack = [user_id]
                visited.add(user_id)
                while stack:
                    node = stack.pop()
                    component.append(node)
                    for neighbor in self.adj[node]:
                        if neighbor not in visited:
                            visited.add(neighbor)
                            stack.append(neighbor)
                component.sort(key=lambda x: self.users[x])
                groups.append([{"id": i, "name": self.users[i]} for i in component])

        groups.sort(key=lambda g: -len(g))
        return groups

    # ─── ۶. کاربران با بیشترین دوست ───────────────────────────────────────────

    def most_friends(self) -> List[dict]:
        """کاربرانی با بیشترین درجه. O(V)."""
        if not self.users:
            return []
        max_deg = max(len(friends) for friends in self.adj.values())
        result = [
            {"id": uid, "name": name, "friend_count": len(self.adj[uid])}
            for uid, name in self.users.items()
            if len(self.adj[uid]) == max_deg
        ]
        result.sort(key=lambda x: x["name"])
        return result

    # ─── ۷. دوستان مشترک ─────────────────────────────────────────────────────

    def common_friends(self, u: str, v: str) -> Optional[List[dict]]:
        """اشتراک دو مجموعه دوستان. O(min(deg(u), deg(v)))."""
        if u not in self.users or v not in self.users:
            return None
        smaller, larger = self.adj[u], self.adj[v]
        if len(smaller) > len(larger):
            smaller, larger = larger, smaller
        common = smaller & larger
        return [
            {"id": c, "name": self.users[c]}
            for c in sorted(common, key=lambda x: self.users[x])
        ]

    # ─── ۸. اطلاعات شبکه ─────────────────────────────────────────────────────

    def network_info(self) -> dict:
        """آمار کلی شبکه. O(V + E)."""
        n = len(self.users)
        e = sum(len(friends) for friends in self.adj.values()) // 2
        avg = (2 * e / n) if n > 0 else 0.0

        groups = self.find_groups()
        largest = groups[0] if groups else []
        top = self.most_friends()

        return {
            "total_users": n,
            "total_friendships": e,
            "average_degree": round(avg, 4),
            "average_degree_fraction": f"{2 * e}/{n}" if n > 0 else "0/0",
            "largest_group": largest,
            "largest_group_size": len(largest),
            "most_friends_users": top,
        }

    # ─── ۹. فاصله کاربر از همه افراد ─────────────────────────────────────────

    def distances_from(self, user_id: str) -> Optional[List[dict]]:
        """BFS از کاربر و مرتب‌سازی بر اساس فاصله. O(V + E)."""
        if user_id not in self.users:
            return None

        dist: Dict[str, int] = {user_id: 0}
        queue = deque([user_id])

        while queue:
            node = queue.popleft()
            for neighbor in self.adj[node]:
                if neighbor not in dist:
                    dist[neighbor] = dist[node] + 1
                    queue.append(neighbor)

        result = []
        for uid, name in self.users.items():
            if uid == user_id:
                continue
            d = dist.get(uid)
            result.append({
                "id": uid,
                "name": name,
                "distance": d if d is not None else -1,  # -1 = غیرقابل‌دسترس
            })

        # قابل‌دسترس‌ها اول (صعودی)، سپس غیرقابل‌دسترس‌ها
        result.sort(key=lambda x: (x["distance"] < 0, x["distance"] if x["distance"] >= 0 else 0, x["name"]))
        return result

    # ─── اختیاری ۱: مرکزیت بینابینی (Brandes) ─────────────────────────────────

    def betweenness_centrality(self) -> List[dict]:
        """
        الگوریتم Brandes برای مرکزیت بینابینی.
        کاربرانی که روی کوتاه‌ترین مسیرهای بیشتری قرار دارند.
        O(V * E) برای گراف بدون وزن.
        """
        if not self.users:
            return []

        cb: Dict[str, float] = {uid: 0.0 for uid in self.users}
        nodes = list(self.users.keys())

        for s in nodes:
            # BFS
            stack = []
            pred: Dict[str, List[str]] = {w: [] for w in nodes}
            sigma: Dict[str, float] = {w: 0.0 for w in nodes}
            dist: Dict[str, int] = {w: -1 for w in nodes}
            sigma[s] = 1.0
            dist[s] = 0
            queue = deque([s])

            while queue:
                v = queue.popleft()
                stack.append(v)
                for w in self.adj[v]:
                    if dist[w] < 0:
                        dist[w] = dist[v] + 1
                        queue.append(w)
                    if dist[w] == dist[v] + 1:
                        sigma[w] += sigma[v]
                        pred[w].append(v)

            delta: Dict[str, float] = {w: 0.0 for w in nodes}
            while stack:
                w = stack.pop()
                for v in pred[w]:
                    if sigma[w] != 0:
                        delta[v] += (sigma[v] / sigma[w]) * (1.0 + delta[w])
                if w != s:
                    cb[w] += delta[w]

        # برای گراف بدون‌جهت، نصف می‌کنیم
        for uid in cb:
            cb[uid] /= 2.0

        result = [
            {"id": uid, "name": self.users[uid], "betweenness": round(cb[uid], 4)}
            for uid in nodes
        ]
        result.sort(key=lambda x: -x["betweenness"])
        return result

    # ─── اختیاری ۲: تشخیص جوامع (Label Propagation) ──────────────────────────

    def detect_communities(self) -> List[List[dict]]:
        """
        الگوریتم Label Propagation برای تشخیص جوامع درون مؤلفه‌ها.
        یال‌های درون‌گروهی متراکم، یال‌های بین‌گروهی کم.
        O(E) در هر تکرار؛ معمولاً همگرایی سریع.
        """
        if not self.users:
            return []

        labels: Dict[str, str] = {uid: uid for uid in self.users}
        nodes = list(self.users.keys())
        max_iter = 50

        for _ in range(max_iter):
            changed = False
            # ترتیب ثابت برای قطعیت نتایج (به جای تصادفی)
            for node in sorted(nodes, key=lambda x: self.users[x]):
                if not self.adj[node]:
                    continue
                # شمارش برچسب همسایه‌ها
                counts: Dict[str, int] = defaultdict(int)
                for neighbor in self.adj[node]:
                    counts[labels[neighbor]] += 1
                # پرتکرارترین برچسب؛ در تساوی، نام کوچک‌تر
                max_count = max(counts.values())
                candidates = [lbl for lbl, c in counts.items() if c == max_count]
                best_label = min(candidates, key=lambda lbl: self.users.get(lbl, lbl))

                if labels[node] != best_label:
                    labels[node] = best_label
                    changed = True
            if not changed:
                break

        communities: Dict[str, List[str]] = defaultdict(list)
        for uid, label in labels.items():
            communities[label].append(uid)

        result = []
        for members in communities.values():
            members.sort(key=lambda x: self.users[x])
            result.append([{"id": i, "name": self.users[i]} for i in members])
        result.sort(key=lambda g: -len(g))
        return result

    # ─── اختیاری ۳: بهینه‌سازی انتشار خبر ────────────────────────────────────

    def optimize_spread(self, k: int) -> dict:
        """
        انتخاب حریصانه K کاربر اولیه برای انتشار سریع‌تر خبر.
        قانون: هر کاربر خبر را روز بعد به همه دوستانش می‌گوید (فقط یک‌بار می‌شنود).
        معیار: کمینه‌کردن حداکثر زمان پوشش + بیشینه‌کردن تعداد پوشش‌داده‌شده.
        """
        if k <= 0 or not self.users:
            return {"seeds": [], "coverage": 0, "days": 0, "timeline": []}

        k = min(k, len(self.users))
        remaining = set(self.users.keys())
        seeds: List[str] = []

        for _ in range(k):
            best_node = None
            best_score = None  # (coverage, -days) بزرگ‌تر بهتر

            for candidate in remaining:
                trial = seeds + [candidate]
                cov, days, _ = self._simulate_spread(trial)
                score = (cov, -days)
                if best_score is None or score > best_score:
                    best_score = score
                    best_node = candidate

            if best_node is None:
                break
            seeds.append(best_node)
            remaining.remove(best_node)

        coverage, days, timeline = self._simulate_spread(seeds)
        return {
            "seeds": [{"id": s, "name": self.users[s]} for s in seeds],
            "coverage": coverage,
            "days": days,
            "timeline": timeline,
            "total_users": len(self.users),
        }

    def _simulate_spread(self, seeds: List[str]) -> Tuple[int, int, List[dict]]:
        """شبیه‌سازی انتشار خبر از seeds. برمی‌گرداند: (پوشش، روزها، جدول زمانی)."""
        if not seeds:
            return 0, 0, []

        informed: Set[str] = set(seeds)
        frontier = list(seeds)
        day = 0
        timeline = [{
            "day": 0,
            "newly_informed": [{"id": s, "name": self.users[s]} for s in seeds],
            "total_informed": len(informed),
        }]

        while frontier:
            next_frontier = []
            for node in frontier:
                for neighbor in self.adj[node]:
                    if neighbor not in informed:
                        informed.add(neighbor)
                        next_frontier.append(neighbor)
            if not next_frontier:
                break
            day += 1
            timeline.append({
                "day": day,
                "newly_informed": [
                    {"id": u, "name": self.users[u]} for u in next_frontier
                ],
                "total_informed": len(informed),
            })
            frontier = next_frontier

        return len(informed), day, timeline

    # ─── سریال‌سازی ──────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        friendships = []
        seen = set()
        for u, friends in self.adj.items():
            for v in friends:
                edge = tuple(sorted([u, v]))
                if edge not in seen:
                    seen.add(edge)
                    friendships.append({"user1": u, "user2": v})
        return {
            "users": [{"id": uid, "name": name} for uid, name in self.users.items()],
            "friendships": friendships,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SocialNetwork":
        net = cls()
        for user in data.get("users", []):
            net.add_user(user["id"], user["name"])
        for edge in data.get("friendships", []):
            net.add_friendship(edge["user1"], edge["user2"])
        return net
