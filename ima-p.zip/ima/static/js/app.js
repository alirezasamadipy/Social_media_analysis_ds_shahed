/* رابط کاربری تحلیل شبکه اجتماعی */

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

function toast(msg) {
  const el = $("#toast");
  el.textContent = msg;
  el.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { el.hidden = true; }, 2500);
}

async function api(url, options = {}) {
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "خطا در درخواست");
  return data;
}

function names(list) {
  if (!list || !list.length) return '<span class="empty">موردی نیست</span>';
  return `<div class="tag-list">${list.map((u) => `<span class="tag">${u.name}</span>`).join("")}</div>`;
}

function pathHtml(path) {
  if (!path || !path.length) return '<span class="empty">مسیری وجود ندارد</span>';
  return `<div class="path">${path.map((u, i) =>
    `<span class="tag">${u.name}</span>${i < path.length - 1 ? '<span class="arrow">←</span>' : ""}`
  ).join("")}</div>`;
}

function groupsHtml(groups, title = "گروه") {
  if (!groups.length) return '<span class="empty">گروهی نیست</span>';
  return groups.map((g, i) => `
    <div class="group-card">
      <h3>${title} ${i + 1} — ${g.length} نفر</h3>
      ${names(g)}
    </div>
  `).join("");
}

/* Tabs */
$$(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    $$(".tab").forEach((t) => t.classList.remove("active"));
    $$(".panel").forEach((p) => p.classList.remove("active"));
    tab.classList.add("active");
    $(`#panel-${tab.dataset.panel}`).classList.add("active");
  });
});

/* User selects */
let usersCache = [];

function fillSelects() {
  const options = usersCache
    .map((u) => `<option value="${u.id}">${u.name} (${u.id})</option>`)
    .join("");
  $$(".user-select, #sel-friend-u, #sel-friend-v").forEach((sel) => {
    const prev = sel.value;
    sel.innerHTML = options;
    if (prev && usersCache.some((u) => u.id === prev)) sel.value = prev;
  });
}

async function refreshUsers() {
  usersCache = await api("/api/users");
  fillSelects();

  const tbody = $("#users-table");
  tbody.innerHTML = usersCache.map((u) => `
    <tr>
      <td><code>${u.id}</code></td>
      <td>${u.name}</td>
      <td>${u.friend_count}</td>
      <td>
        <button class="ghost" data-edit="${u.id}" data-name="${u.name}">ویرایش</button>
        <button class="danger" data-del-user="${u.id}">حذف</button>
      </td>
    </tr>
  `).join("") || '<tr><td colspan="4" class="empty">کاربری نیست</td></tr>';

  const edges = await api("/api/friendships");
  $("#edges-table").innerHTML = edges.map((e) => `
    <tr>
      <td>${e.user1_name}</td>
      <td>${e.user2_name}</td>
      <td>
        <button class="danger" data-del-edge="${e.user1}|${e.user2}">حذف</button>
      </td>
    </tr>
  `).join("") || '<tr><td colspan="3" class="empty">رابطه‌ای نیست</td></tr>';

  try {
    const info = (await api("/api/network-info")).info;
    $("#quick-stats").innerHTML = `
      <span class="chip">کاربران: <strong>${info.total_users}</strong></span>
      <span class="chip">روابط: <strong>${info.total_friendships}</strong></span>
      <span class="chip">میانگین درجه: <strong>${info.average_degree}</strong></span>
    `;
  } catch (_) { /* ignore */ }
}

/* Manage forms */
$("#form-add-user").addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  try {
    await api("/api/users", {
      method: "POST",
      body: JSON.stringify({ id: fd.get("id"), name: fd.get("name") }),
    });
    e.target.reset();
    toast("کاربر افزوده شد");
    await refreshUsers();
  } catch (err) {
    toast(err.message);
  }
});

$("#form-add-friendship").addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  try {
    await api("/api/friendships", {
      method: "POST",
      body: JSON.stringify({ user1: fd.get("user1"), user2: fd.get("user2") }),
    });
    toast("دوستی ایجاد شد");
    await refreshUsers();
  } catch (err) {
    toast(err.message);
  }
});

document.addEventListener("click", async (e) => {
  const delUser = e.target.closest("[data-del-user]");
  if (delUser) {
    if (!confirm("حذف این کاربر و تمام روابطش؟")) return;
    try {
      await api(`/api/users/${delUser.dataset.delUser}`, { method: "DELETE" });
      toast("کاربر حذف شد");
      await refreshUsers();
    } catch (err) { toast(err.message); }
    return;
  }

  const edit = e.target.closest("[data-edit]");
  if (edit) {
    const name = prompt("نام جدید:", edit.dataset.name);
    if (!name) return;
    try {
      await api(`/api/users/${edit.dataset.edit}`, {
        method: "PUT",
        body: JSON.stringify({ name }),
      });
      toast("نام به‌روز شد");
      await refreshUsers();
    } catch (err) { toast(err.message); }
    return;
  }

  const delEdge = e.target.closest("[data-del-edge]");
  if (delEdge) {
    const [user1, user2] = delEdge.dataset.delEdge.split("|");
    try {
      await api("/api/friendships", {
        method: "DELETE",
        body: JSON.stringify({ user1, user2 }),
      });
      toast("رابطه حذف شد");
      await refreshUsers();
    } catch (err) { toast(err.message); }
  }
});

/* Query actions */
const actions = {
  async friends() {
    const id = $("#q1-user").value;
    const data = await api(`/api/friends/${id}`);
    $("#r1").innerHTML = names(data.friends);
  },

  async connected() {
    const u = $("#q2-u").value;
    const v = $("#q2-v").value;
    const data = await api(`/api/connected?u=${u}&v=${v}`);
    $("#r2").innerHTML = data.connected
      ? '<span class="yes">بله — مرتبط هستند</span>'
      : '<span class="no">خیر — مرتبط نیستند</span>';
  },

  async path() {
    const u = $("#q3-u").value;
    const v = $("#q3-v").value;
    const data = await api(`/api/shortest-path?u=${u}&v=${v}`);
    if (!data.path.length) {
      $("#r3").innerHTML = '<span class="empty">مسیری وجود ندارد (در یک گروه نیستند)</span>';
    } else {
      $("#r3").innerHTML = `${pathHtml(data.path)}<div class="empty" style="margin-top:.4rem">طول مسیر: ${data.length}</div>`;
    }
  },

  async suggest() {
    const id = $("#q4-user").value;
    const data = await api(`/api/suggest/${id}`);
    $("#r4").innerHTML = names(data.suggestions);
  },

  async groups() {
    const data = await api("/api/groups");
    $("#r5").innerHTML = groupsHtml(data.groups);
  },

  async most() {
    const data = await api("/api/most-friends");
    $("#r6").innerHTML = data.users.map((u) =>
      `<div><strong>${u.name}</strong> با ${u.friend_count} دوست</div>`
    ).join("") || '<span class="empty">—</span>';
  },

  async common() {
    const u = $("#q7-u").value;
    const v = $("#q7-v").value;
    const data = await api(`/api/common-friends?u=${u}&v=${v}`);
    $("#r7").innerHTML = names(data.common);
  },

  async info() {
    const data = await api("/api/network-info");
    const i = data.info;
    const top = i.most_friends_users.map((u) => `${u.name} (${u.friend_count})`).join("، ");
    const largest = i.largest_group.map((u) => u.name).join("، ");
    $("#r8").innerHTML = `
      <div class="info-card"><div class="label">تعداد کل کاربران</div><div class="value">${i.total_users}</div></div>
      <div class="info-card"><div class="label">تعداد کل دوستی‌ها</div><div class="value">${i.total_friendships}</div></div>
      <div class="info-card">
        <div class="label">میانگین روابط به ازای هر کاربر</div>
        <div class="value">${i.average_degree}</div>
        <div class="sub">کسر: ${i.average_degree_fraction}  (فرمول: ۲E / N)</div>
      </div>
      <div class="info-card">
        <div class="label">بزرگ‌ترین گروه دوستی</div>
        <div class="value">${i.largest_group_size} نفر</div>
        <div class="sub">(${largest || "—"})</div>
      </div>
      <div class="info-card">
        <div class="label">کاربر با بیشترین دوست</div>
        <div class="value" style="font-size:1.05rem">${top || "—"}</div>
      </div>
    `;
  },

  async distances() {
    const id = $("#q9-user").value;
    const data = await api(`/api/distances/${id}`);
    if (!data.distances.length) {
      $("#r9").innerHTML = '<span class="empty">کاربر دیگری نیست</span>';
      return;
    }
    $("#r9").innerHTML = `
      <div class="table-wrap"><table>
        <thead><tr><th>کاربر</th><th>فاصله</th></tr></thead>
        <tbody>
          ${data.distances.map((d) => `
            <tr>
              <td>${d.name}</td>
              <td>${d.distance < 0 ? '<span class="no">غیرقابل‌دسترس</span>' : d.distance}</td>
            </tr>
          `).join("")}
        </tbody>
      </table></div>
    `;
  },

  async betweenness() {
    const data = await api("/api/betweenness");
    $("#ro1").innerHTML = `
      <div class="table-wrap"><table>
        <thead><tr><th>رتبه</th><th>کاربر</th><th>مرکزیت بینابینی</th></tr></thead>
        <tbody>
          ${data.users.map((u, i) => `
            <tr>
              <td>${i + 1}</td>
              <td>${u.name}</td>
              <td>${u.betweenness}</td>
            </tr>
          `).join("")}
        </tbody>
      </table></div>
    `;
  },

  async communities() {
    const data = await api("/api/communities");
    $("#ro2").innerHTML = groupsHtml(data.communities, "جامعه");
  },

  async spread() {
    const k = $("#spread-k").value || 2;
    const data = await api(`/api/spread?k=${k}`);
    const r = data.result;
    const days = r.timeline.map((t) => `
      <div class="group-card">
        <h3>روز ${t.day} — مجموع مطلع: ${t.total_informed}</h3>
        ${names(t.newly_informed)}
      </div>
    `).join("");
    $("#ro3").innerHTML = `
      <p><strong>کاربران اولیه:</strong></p>
      ${names(r.seeds)}
      <p style="margin-top:.8rem">پوشش: <strong>${r.coverage}</strong> از ${r.total_users} نفر در <strong>${r.days}</strong> روز</p>
      ${days}
    `;
  },
};

document.addEventListener("click", async (e) => {
  const btn = e.target.closest("[data-action]");
  if (!btn) return;
  const action = btn.dataset.action;
  if (!actions[action]) return;
  btn.disabled = true;
  try {
    await actions[action]();
  } catch (err) {
    toast(err.message);
  } finally {
    btn.disabled = false;
  }
});

refreshUsers().then(() => actions.info()).catch((err) => toast(err.message));
